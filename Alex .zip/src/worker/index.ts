import { Hono } from "hono";
import { cors } from "hono/cors";
import OpenAI from "openai";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors());

app.post("/api/chat", async (c) => {
  try {
    const { messages } = await c.req.json();

    if (!messages || !Array.isArray(messages)) {
      return c.json({ error: "Invalid request: messages array required" }, 400);
    }

    const client = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: messages,
      temperature: 0.7,
      max_tokens: 2000,
    });

    const assistantMessage = response.choices[0].message.content;

    return c.json({
      message: assistantMessage,
      usage: response.usage,
    });
  } catch (error: any) {
    console.error("OpenAI API error:", error);
    
    // Handle specific OpenAI API errors
    if (error?.status === 429) {
      return c.json(
        { error: "OpenAI API quota exceeded. Please check your billing at platform.openai.com/account/billing" },
        429
      );
    }
    
    if (error?.status === 401) {
      return c.json(
        { error: "Invalid OpenAI API key. Please update it in the app settings." },
        401
      );
    }
    
    return c.json(
      { error: error?.message || "Failed to generate response. Please try again." },
      500
    );
  }
});

export default app;

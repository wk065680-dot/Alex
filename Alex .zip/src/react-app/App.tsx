import { BrowserRouter as Router, Routes, Route } from "react-router";
import LandingPage from "@/react-app/pages/Landing";
import ChatPage from "@/react-app/pages/Chat";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/chat" element={<ChatPage />} />
      </Routes>
    </Router>
  );
}

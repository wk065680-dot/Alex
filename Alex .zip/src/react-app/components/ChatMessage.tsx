import { Sparkles, User } from 'lucide-react';

interface ChatMessageProps {
  role: 'user' | 'assistant';
  content: string;
}

export default function ChatMessage({ role, content }: ChatMessageProps) {
  const isUser = role === 'user';
  
  return (
    <div className={`group flex gap-4 px-6 py-6 transition-colors ${
      isUser 
        ? 'bg-slate-50/50 dark:bg-slate-900/30 hover:bg-slate-100/50 dark:hover:bg-slate-900/40' 
        : 'hover:bg-slate-50/30 dark:hover:bg-slate-950/30'
    } rounded-2xl`}>
      <div className={`flex-shrink-0 w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-105 ${
        isUser 
          ? 'bg-gradient-to-br from-slate-700 to-slate-900 dark:from-slate-200 dark:to-slate-400 text-white dark:text-slate-900 shadow-slate-400/20 dark:shadow-slate-600/20' 
          : 'bg-gradient-to-br from-violet-600 via-purple-600 to-blue-600 text-white shadow-purple-500/20'
      }`}>
        {isUser ? <User className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/10 to-transparent pointer-events-none"></div>
      </div>
      <div className="flex-1 space-y-2 min-w-0">
        <div className="font-semibold text-sm text-slate-900 dark:text-slate-100">
          {isUser ? 'You' : 'Cognito AI'}
        </div>
        <div className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap break-words">
          {content}
        </div>
      </div>
    </div>
  );
}

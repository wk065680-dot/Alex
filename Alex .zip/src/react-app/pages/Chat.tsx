import { useState, useRef, useEffect } from 'react';
import { Sparkles, AlertCircle, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router';
import ChatMessage from '@/react-app/components/ChatMessage';
import ChatInput from '@/react-app/components/ChatInput';
import { Alert, AlertDescription } from '@/react-app/components/ui/alert';
import { Button } from '@/react-app/components/ui/button';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Hello! I\'m Cognito AI, an advanced AI assistant powered by GPT-4o-mini. I can help you with coding, writing, analysis, creative projects, and much more. What would you like to work on today?',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    if (!content.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMessage],
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        
        if (response.status === 401) {
          throw new Error('API authentication failed. Please check your OpenAI API key in Settings.');
        } else if (response.status === 429) {
          throw new Error('Rate limit exceeded. Please check your OpenAI API quota or try again later.');
        } else {
          throw new Error(errorData.error || `Server error: ${response.status}`);
        }
      }

      const data = await response.json();
      const assistantMessage: Message = {
        role: 'assistant',
        content: data.message,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      console.error('Chat error:', err);
      setError(err instanceof Error ? err.message : 'Failed to send message. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 backdrop-blur-xl bg-background/80 border-b border-border/50 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Link>
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 via-lime-400 to-cyan-500 flex items-center justify-center shadow-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold bg-gradient-to-r from-green-600 via-lime-500 to-cyan-500 bg-clip-text text-transparent">
                  Cognito AI
                </h1>
                <p className="text-xs text-muted-foreground">Your AI Assistant</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-4 py-8">
          {error && (
            <Alert variant="destructive" className="mb-6 backdrop-blur-lg bg-destructive/10 border-destructive/30">
              <AlertCircle className="h-5 w-5" />
              <AlertDescription className="ml-2">{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-6">
            {messages.map((message, index) => (
              <ChatMessage key={index} role={message.role} content={message.content} />
            ))}
            {isLoading && (
              <ChatMessage
                role="assistant"
                content="Thinking..."
              />
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>
      </div>

      {/* Input Area */}
      <div className="sticky bottom-0 backdrop-blur-xl bg-gradient-to-t from-background via-background/95 to-transparent border-t border-border/30">
        <div className="max-w-5xl mx-auto px-4 py-6">
          <ChatInput onSend={handleSendMessage} disabled={isLoading} />
          <p className="text-xs text-center text-muted-foreground mt-4">
            Cognito AI can make mistakes. Consider checking important information.
          </p>
        </div>
      </div>
    </div>
  );
}

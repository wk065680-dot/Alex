import { useState } from 'react';
import { Link } from 'react-router';
import { Button } from '@/react-app/components/ui/button';
import { Input } from '@/react-app/components/ui/input';
import { Sparkles, ArrowRight } from 'lucide-react';

export default function Landing() {
  const [prompt, setPrompt] = useState('');

  const examplePrompts = [
    'A fitness tracker with progress charts',
    'A recipe sharing platform with ratings',
    'A task manager with team collaboration',
    'A portfolio website with a blog',
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="text-xl font-bold">Cognito AI</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-medium hover:text-primary transition-colors">
              Features
            </a>
            <a href="#how-it-works" className="text-sm font-medium hover:text-primary transition-colors">
              How It Works
            </a>
            <a href="#pricing" className="text-sm font-medium hover:text-primary transition-colors">
              Pricing
            </a>
          </div>

          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link to="/chat">Try Chat</Link>
            </Button>
            <Button className="bg-primary hover:bg-primary/90" asChild>
              <Link to="/chat">
                Get Started <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-green-400 via-lime-300 to-cyan-400 opacity-20" />
        
        {/* Organic Blobs */}
        <div className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-br from-lime-300 to-cyan-300 rounded-full blur-3xl opacity-30 animate-pulse" />
        <div className="absolute bottom-10 right-10 w-80 h-80 bg-gradient-to-tr from-green-300 to-lime-400 rounded-full blur-3xl opacity-25 animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-64 bg-gradient-to-r from-cyan-200 to-lime-200 rounded-full blur-3xl opacity-20" />

        <div className="relative max-w-5xl mx-auto text-center">
          <h1 className="text-6xl md:text-7xl lg:text-8xl font-black mb-6 leading-tight">
            Build anything
            <br />
            <span className="bg-gradient-to-r from-green-600 via-lime-500 to-cyan-500 bg-clip-text text-transparent">
              with AI.
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Create intelligent applications with words, not code. Powered by advanced AI technology.
          </p>

          {/* Interactive Prompt Box */}
          <div className="max-w-3xl mx-auto mb-8">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-lime-300 via-green-400 to-cyan-400 rounded-2xl blur-lg opacity-30" />
              <div className="relative bg-background/95 backdrop-blur-xl border border-border/50 rounded-2xl shadow-2xl overflow-hidden">
                <div className="p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <Sparkles className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-muted-foreground">
                      Try it now
                    </span>
                  </div>
                  <Input
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={examplePrompts[Math.floor(Math.random() * examplePrompts.length)]}
                    className="text-lg h-14 bg-background/50 border-border/50"
                  />
                  <div className="flex justify-end mt-4">
                    <Button 
                      size="lg" 
                      className="bg-gradient-to-r from-green-500 to-cyan-500 hover:from-green-600 hover:to-cyan-600 text-white font-semibold"
                      asChild
                    >
                      <Link to="/chat">
                        Start Building <ArrowRight className="w-4 h-4 ml-2" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="flex flex-wrap justify-center gap-12 mt-16">
            <div>
              <div className="text-4xl font-bold bg-gradient-to-r from-green-600 to-cyan-500 bg-clip-text text-transparent">
                10K+
              </div>
              <div className="text-sm text-muted-foreground mt-1">Apps Created</div>
            </div>
            <div>
              <div className="text-4xl font-bold bg-gradient-to-r from-lime-500 to-green-500 bg-clip-text text-transparent">
                50K+
              </div>
              <div className="text-sm text-muted-foreground mt-1">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold bg-gradient-to-r from-cyan-500 to-lime-400 bg-clip-text text-transparent">
                99.9%
              </div>
              <div className="text-sm text-muted-foreground mt-1">Uptime</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Preview */}
      <section id="features" className="py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
            Everything you need to{' '}
            <span className="bg-gradient-to-r from-green-600 to-cyan-500 bg-clip-text text-transparent">
              succeed
            </span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Natural Language',
                description: 'Describe what you want in plain English. No coding required.',
                gradient: 'from-green-500 to-lime-400',
              },
              {
                title: 'Instant Results',
                description: 'See your ideas come to life in real-time as you chat.',
                gradient: 'from-lime-400 to-cyan-400',
              },
              {
                title: 'Production Ready',
                description: 'Deploy and share your creations with the world instantly.',
                gradient: 'from-cyan-400 to-green-500',
              },
            ].map((feature, i) => (
              <div key={i} className="relative group">
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} rounded-2xl blur-xl opacity-20 group-hover:opacity-30 transition-opacity`} />
                <div className="relative bg-background/80 backdrop-blur-xl border border-border/50 rounded-2xl p-8 h-full hover:border-primary/50 transition-all">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} mb-4 flex items-center justify-center`}>
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to start building?
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join thousands of creators bringing their ideas to life with AI.
          </p>
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-green-500 to-cyan-500 hover:from-green-600 hover:to-cyan-600 text-white font-semibold text-lg px-8 h-14"
            asChild
          >
            <Link to="/chat">
              Get Started Free <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              <span className="font-bold">Cognito AI</span>
            </div>
            <div className="flex gap-8 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
              <a href="#" className="hover:text-foreground transition-colors">Terms</a>
              <a href="#" className="hover:text-foreground transition-colors">Contact</a>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 Cognito AI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState, useRef, useEffect } from 'react';
import { Sparkles, AlertCircle } from 'lucide-react';
import ChatMessage from '@/react-app/components/ChatMessage';
import ChatInput from '@/react-app/components/ChatInput';
import { Alert, AlertDescription } from '@/react-app/components/ui/alert';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Hello! I\'m Cognito AI, an advanced AI assistant powered by GPT-4o-mini. I can help you with coding, writing, analysis, creative projects, and much more. What would you like to work on today?',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (content: string) => {
    const userMessage: Message = { role: 'user', content };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((msg) => ({
            role: msg.role,
            content: msg.content,
          })),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 429) {
          setError('Your OpenAI API key has exceeded its quota. Please check your billing at platform.openai.com/account/billing');
        } else if (response.status === 401) {
          setError('Invalid OpenAI API key. Please update it in the app settings.');
        } else {
          setError(data.error || 'An error occurred while generating a response.');
        }
        return;
      }

      const assistantMessage: Message = {
        role: 'assistant',
        content: data.message,
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error:', error);
      setError('Failed to connect to the API. Please check your internet connection and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      {/* Header */}
      <div className="border-b border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl sticky top-0 z-10 shadow-sm">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center gap-3">
          <div className="relative w-11 h-11 rounded-2xl bg-gradient-to-br from-violet-600 via-purple-600 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
            <Sparkles className="w-6 h-6 text-white drop-shadow-sm" />
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent"></div>
          </div>
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-violet-600 via-purple-600 to-blue-600 bg-clip-text text-transparent">
              Cognito AI
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Powered by GPT-4o-mini</p>
          </div>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="max-w-5xl mx-auto w-full px-6 pt-4">
          <Alert variant="destructive" className="shadow-lg border-red-200 dark:border-red-900/50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-sm">{error}</AlertDescription>
          </Alert>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-6 py-8">
          <div className="space-y-1">
            {messages.map((message, index) => (
              <ChatMessage key={index} role={message.role} content={message.content} />
            ))}
          </div>
          {isLoading && (
            <div className="flex gap-4 px-6 py-8 animate-in fade-in duration-300">
              <div className="flex-shrink-0 w-10 h-10 rounded-2xl bg-gradient-to-br from-violet-600 via-purple-600 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
                <Sparkles className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div className="flex gap-1.5 items-center pt-2">
                <div className="w-2 h-2 bg-gradient-to-br from-violet-600 to-purple-600 rounded-full animate-bounce shadow-sm" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full animate-bounce shadow-sm" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-gradient-to-br from-blue-600 to-violet-600 rounded-full animate-bounce shadow-sm" style={{ animationDelay: '300ms' }}></div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="max-w-5xl mx-auto w-full px-6 pb-6">
        <ChatInput onSend={handleSend} disabled={isLoading} />
      </div>
    </div>
  );
}

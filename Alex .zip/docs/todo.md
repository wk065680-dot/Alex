# Todo
- #6: Add features section to landing page
- #7: Add footer with links
- #8: Add conversation history and streaming responses to chat
- #9: Add example prompts/suggestions for new users in chat
- #10: Add ability to clear conversation history
